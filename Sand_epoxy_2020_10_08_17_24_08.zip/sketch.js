var monkey = createSprite(200,380,20,50);
monkey.setAnimation ("monkey");
monkey.scale = 0.1

var ground = createSprite(200,380,400,20);
ground.x = ground.width /2;

var invisibleGround = createSprite(200,385,400,5);
invisibleGround.visible = false;


var ObstaclesGroup = createGroup();
var BananasGroup = createGroup(); 
banana.setAnimation("banana");

function spawnBananas() {
  if(World.frameCount % 60 === 0) {
    var bananas = createSprite(400,365,10,40);
    bananas.velocityX = - (6 /100);
  
    
    var rand = randomNumber(1,6);
    bananas.setAnimation("obstacle" + rand);
    
    bananas.scale = 0.5;
    bananas.lifetime = 70;
  }
}





function draw() {
    
  background("white");
    
    if(keyDown("space") && monkey.y >= 359){
      monkey.velocityY = -12 ;
      playSound("jump.mp3");
    }
  
  
    monkey.velocityY = monkey.velocityY + 0.8;
    
  
  
  background(255);
  
    
 drawSprites(); 
}




  




function setup() {
  createCanvas(400, 400);
}